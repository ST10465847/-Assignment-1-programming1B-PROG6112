package com.mycompany.medicarehospital2;

import java.util.Scanner;

/**
 * Main entry point for the MediCare Hospital System.
 * Manages the console interactive menu for patient registration, search, reports, and bed management.
 */
public class MediCareHospital2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        WardManager wardManager = new WardManager();
        boolean running = true;

        System.out.println("==========================================");
        System.out.println("   WELCOME TO MEDICARE HOSPITAL SYSTEM    ");
        System.out.println("==========================================");

        while (running) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. Register New Patient");
            System.out.println("2. Search Patient by ID");
            System.out.println("3. Allocate Bed (Inpatients Only)");
            System.out.println("4. Discharge Patient / Release Bed");
            System.out.println("5. Display Ward Layout Matrix");
            System.out.println("6. Display Sorted Patient Report");
            System.out.println("7. Display Ward Occupancy Statistics");
            System.out.println("8. Exit");
            System.out.print("Select an option (1-8): ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    System.out.print("Enter Patient ID: ");
                    String id = scanner.nextLine().trim();
                    
                    if (wardManager.findPatientById(id) != null) {
                        System.out.println("Error: A patient with ID " + id + " already exists!");
                        break;
                    }

                    System.out.print("Enter First Name: ");
                    String firstName = scanner.nextLine().trim();

                    System.out.print("Enter Last Name: ");
                    String lastName = scanner.nextLine().trim();

                    System.out.print("Enter Age: ");
                    int age = Integer.parseInt(scanner.nextLine().trim());

                    System.out.print("Enter Gender: ");
                    String gender = scanner.nextLine().trim();

                    System.out.print("Enter Medical Condition: ");
                    String condition = scanner.nextLine().trim();

                    System.out.println("Select Category: 1. Inpatient | 2. Outpatient | 3. Emergency");
                    System.out.print("Enter choice (1-3): ");
                    int catChoice = Integer.parseInt(scanner.nextLine().trim());

                    Patient newPatient;
                    if (catChoice == 1) {
                        newPatient = new Inpatient(id, firstName, lastName, age, gender, condition);
                    } else {
                        PatientCategory category = (catChoice == 3) ? PatientCategory.EMERGENCY : PatientCategory.OUTPATIENT;
                        newPatient = new Patient(id, firstName, lastName, age, gender, condition, category);
                    }

                    wardManager.addPatient(newPatient);
                    System.out.println("Patient registered successfully!");
                    break;

                case "2":
                    System.out.print("Enter Patient ID to search: ");
                    String searchId = scanner.nextLine().trim();
                    Patient found = wardManager.findPatientById(searchId);
                    if (found != null) {
                        System.out.println("Patient Found: " + found.getDetails());
                    } else {
                        System.out.println("Patient with ID " + searchId + " not found.");
                    }
                    break;

                case "3":
                    System.out.print("Enter Inpatient ID: ");
                    String patientId = scanner.nextLine().trim();
                    Patient p = wardManager.findPatientById(patientId);

                    if (p == null) {
                        System.out.println("Error: No patient found with ID " + patientId + ".");
                        break;
                    }

                    if (!(p instanceof Inpatient)) {
                        System.out.println("Error: Patient " + p.getFirstName() + " " + p.getLastName() + 
                                           " is registered as " + p.getCategory() + ". Only Inpatients can be allocated ward beds!");
                        break;
                    }

                    Inpatient inpatient = (Inpatient) p;

                    if (!inpatient.getAllocatedBedId().equals("Unallocated") && !inpatient.getAllocatedBedId().equals("Discharged")) {
                        System.out.println("Warning: Patient " + inpatient.getFirstName() + " is already assigned to Bed " + inpatient.getAllocatedBedId() + "!");
                        break;
                    }

                    wardManager.displayWardMatrix();
                    System.out.print("Enter Bed Code to allocate (e.g., B01 or B1): ");
                    String bedCode = scanner.nextLine().trim();

                    if (wardManager.allocateBed(inpatient, bedCode)) {
                        System.out.println("Success! Bed " + inpatient.getAllocatedBedId() + " successfully allocated to " + inpatient.getFirstName() + " " + inpatient.getLastName() + ".");
                    } else {
                        System.out.println("Allocation failed. Either the ward is full, or the bed code was invalid/already occupied.");
                    }
                    break;

                case "4":
                    System.out.print("Enter Bed Code to release (e.g., B01): ");
                    String releaseBed = scanner.nextLine().trim();
                    if (wardManager.releaseBed(releaseBed)) {
                        System.out.println("Bed " + releaseBed + " released successfully.");
                    } else {
                        System.out.println("Invalid bed code or bed already free.");
                    }
                    break;

                case "5":
                    wardManager.displayWardMatrix();
                    break;

                case "6":
                    wardManager.printPatientReportSorted();
                    break;

                case "7":
                    wardManager.printOccupancyReport();
                    break;

                case "8":
                    running = false;
                    System.out.println("Exiting MediCare Hospital System. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 8.");
            }
        }
        scanner.close();
    }
}