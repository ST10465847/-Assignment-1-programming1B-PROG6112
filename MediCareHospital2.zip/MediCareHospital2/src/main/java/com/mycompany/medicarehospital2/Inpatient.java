package com.mycompany.medicarehospital2;

/**
 * Class representing an admitted inpatient, inheriting from Patient.
 * Demonstrates OOP Inheritance and Constructor Chaining using super().
 */
public class Inpatient extends Patient {
    private String allocatedBedId;

    /**
     * Constructor for Inpatient records. Automatically sets category to INPATIENT via super().
     *
     * @param patientId        Unique patient ID.
     * @param firstName        Patient's first name.
     * @param lastName         Patient's last name.
     * @param age              Patient's age.
     * @param gender           Patient's gender.
     * @param medicalCondition Medical condition upon admission.
     */
    public Inpatient(String patientId, String firstName, String lastName, int age, String gender, String medicalCondition) {
        super(patientId, firstName, lastName, age, gender, medicalCondition, PatientCategory.INPATIENT);
        this.allocatedBedId = "Unallocated";
    }

    public String getAllocatedBedId() { return allocatedBedId; }
    public void setAllocatedBedId(String allocatedBedId) { this.allocatedBedId = allocatedBedId; }

    /**
     * Overrides base getDetails() method to append bed allocation status.
     * Demonstrates OOP Method Overriding.
     *
     * @return Extended patient detail string.
     */
    @Override
    public String getDetails() {
        return super.getDetails() + String.format(" | Bed: %s", allocatedBedId);
    }
}