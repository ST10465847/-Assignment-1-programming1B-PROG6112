package com.mycompany.medicarehospital2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Manages the 20-bed hospital ward using a 4x5 2D matrix array.
 * Controls bed allocations, discharges, patient search, and report generation.
 */
public class WardManager {
    private static final int ROWS = 4;
    private static final int COLS = 5;
    private final String[][] bedMatrix;
    private final List<Patient> patientRegistry;

    /**
     * Initializes a 4x5 ward matrix with bed codes (B01 to B20) and empty registry.
     */
    public WardManager() {
        this.bedMatrix = new String[ROWS][COLS];
        this.patientRegistry = new ArrayList<>();
        initializeBeds();
    }

    /**
     * Populates the 2D array with default bed identification codes.
     */
    private void initializeBeds() {
        int bedNumber = 1;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                bedMatrix[r][c] = String.format("B%02d", bedNumber++);
            }
        }
    }

    /**
     * Registers a new patient after checking for duplicate IDs.
     *
     * @param patient Patient object to add.
     * @return True if added successfully, false if ID already exists.
     */
    public boolean addPatient(Patient patient) {
        if (findPatientById(patient.getPatientId()) != null) {
            return false;
        }
        patientRegistry.add(patient);
        return true;
    }

    /**
     * Searches for a patient in the registry by their unique ID.
     *
     * @param id Patient ID.
     * @return Patient object if found, null otherwise.
     */
    public Patient findPatientById(String id) {
        for (Patient p : patientRegistry) {
            if (p.getPatientId().equalsIgnoreCase(id.trim())) {
                return p;
            }
        }
        return null;
    }

    /**
     * Allocates a specific bed to an Inpatient if available.
     * Accepts flexible input formats like "B1", "b1", or "B01".
     *
     * @param inpatient Inpatient requesting a bed.
     * @param bedCode   Target bed code.
     * @return True if allocation succeeded, false if invalid or occupied.
     */
    public boolean allocateBed(Inpatient inpatient, String bedCode) {
        if (isWardFull()) return false;

        // Normalize input (converts "b1" or "B1" to "B01")
        String formattedCode = bedCode.toUpperCase().trim();
        if (formattedCode.matches("B\\d")) {
            formattedCode = "B0" + formattedCode.substring(1);
        }

        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (bedMatrix[r][c].equalsIgnoreCase(formattedCode)) {
                    bedMatrix[r][c] = inpatient.getPatientId();
                    inpatient.setAllocatedBedId(formattedCode);
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Releases an occupied bed upon patient discharge.
     *
     * @param bedCode Code of the bed to release.
     * @return True if released successfully, false if bed code not found.
     */
    public boolean releaseBed(String bedCode) {
        String formattedCode = bedCode.toUpperCase().trim();
        if (formattedCode.matches("B\\d")) {
            formattedCode = "B0" + formattedCode.substring(1);
        }

        int bedNum = 1;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                String defaultCode = String.format("B%02d", bedNum);
                if (defaultCode.equalsIgnoreCase(formattedCode)) {
                    String patientId = bedMatrix[r][c];
                    Patient p = findPatientById(patientId);
                    if (p instanceof Inpatient) {
                        ((Inpatient) p).setAllocatedBedId("Discharged");
                    }
                    bedMatrix[r][c] = defaultCode;
                    return true;
                }
                bedNum++;
            }
        }
        return false;
    }

    /**
     * Counts currently occupied beds in the ward.
     *
     * @return Occupied bed count.
     */
    public int getOccupiedCount() {
        int occupied = 0;
        int bedNum = 1;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                String defaultCode = String.format("B%02d", bedNum++);
                if (!bedMatrix[r][c].equals(defaultCode)) {
                    occupied++;
                }
            }
        }
        return occupied;
    }

    /**
     * Checks if all 20 beds are currently occupied.
     *
     * @return True if capacity is reached.
     */
    public boolean isWardFull() {
        return getOccupiedCount() >= (ROWS * COLS);
    }

    /**
     * Displays a visual layout of the 4x5 ward matrix showing occupied and free beds.
     */
    public void displayWardMatrix() {
        System.out.println("\n--- Current Ward Bed Matrix (4x5) ---");
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                System.out.printf("[%-8s] ", bedMatrix[r][c]);
            }
            System.out.println();
        }
    }

    /**
     * Displays all patients sorted alphabetically by last name.
     */
    public void printPatientReportSorted() {
        List<Patient> sortedList = new ArrayList<>(patientRegistry);
        sortedList.sort(Comparator.comparing(Patient::getLastName, String.CASE_INSENSITIVE_ORDER));

        System.out.println("\n--- Patient Admission Report (Sorted by Last Name) ---");
        for (Patient p : sortedList) {
            System.out.println(p.getDetails());
        }
    }

    /**
     * Displays ward occupancy statistics and occupancy percentage.
     */
    public void printOccupancyReport() {
        int occupied = getOccupiedCount();
        int total = ROWS * COLS;
        double percentage = ((double) occupied / total) * 100;

        System.out.println("\n--- Ward Occupancy Report ---");
        System.out.printf("Total Capacity: %d beds\n", total);
        System.out.printf("Occupied Beds:  %d beds\n", occupied);
        System.out.printf("Available Beds: %d beds\n", (total - occupied));
        System.out.printf("Occupancy Rate: %.2f%%\n", percentage);
    }

    public List<Patient> getPatientRegistry() { return patientRegistry; }
}
