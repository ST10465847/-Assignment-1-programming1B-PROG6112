package com.mycompany.medicarehospital2;

// Enum representing the valid admission categories for patients.
 
public enum PatientCategory {
    INPATIENT,
    OUTPATIENT,
    EMERGENCY
}