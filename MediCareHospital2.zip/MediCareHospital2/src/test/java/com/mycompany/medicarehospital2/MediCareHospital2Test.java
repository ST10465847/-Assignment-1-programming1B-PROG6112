package com.mycompany.medicarehospital2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test suite for MediCare Hospital System using JUnit 5.
 */
public class MediCareHospital2Test {
    private WardManager ward;
    private Inpatient inpatient;

    @BeforeEach
    public void setUp() {
        ward = new WardManager();
        inpatient = new Inpatient("P100", "Sinethemba", "Sithole", 22, "Female", "Observation");
    }

    @Test
    public void testInpatientInheritanceAndSuper() {
        assertEquals("P100", inpatient.getPatientId());
        assertEquals(PatientCategory.INPATIENT, inpatient.getCategory());
        assertTrue(inpatient.getDetails().contains("Bed: Unallocated"));
    }

    @Test
    public void testBedAllocationAndRelease() {
        assertTrue(ward.allocateBed(inpatient, "B01"));
        assertEquals("B01", inpatient.getAllocatedBedId());
        assertEquals(1, ward.getOccupiedCount());

        assertTrue(ward.releaseBed("B01"));
        assertEquals(0, ward.getOccupiedCount());
    }

    @Test
    public void testWardFullBoundaryCondition() {
        for (int i = 1; i <= 20; i++) {
            String bedCode = String.format("B%02d", i);
            Inpatient temp = new Inpatient("P" + i, "Test", "User", 30, "M", "Flu");
            ward.allocateBed(temp, bedCode);
        }

        assertTrue(ward.isWardFull());
        Inpatient extraPatient = new Inpatient("P999", "Extra", "User", 40, "F", "Cold");
        assertFalse(ward.allocateBed(extraPatient, "B01"));
    }
}